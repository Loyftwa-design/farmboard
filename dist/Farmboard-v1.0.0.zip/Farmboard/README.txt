Farmboard v1.0.0
================
Author: Loyftwa
Game: World of Warcraft: Midnight

Farmboard is a lightweight farming goal tracker for World of Warcraft.
Create multiple boards, assign items by drag & drop, set target amounts and
track your farming progress directly in-game.

FEATURES
--------
- Multiple independent Farmboards
- Drag & drop items into tracking slots
- Custom goal amounts from 1 to 9999
- Live item counts for bags, character bank and Warband/Account Bank
- Midnight crafting/reagent quality marker on tracked items
- Free slot count from 1 to 24 per board
- Horizontal and vertical layouts
- Movable and lockable boards
- Rename, duplicate, show/hide and delete boards
- Minimap button with global board management
- Goal-complete marker, sound and centered "- Ziel Erreicht! -" notification
- Persistent settings via SavedVariables
- No external libraries required

QUICK START
-----------
1. Drag an item from your bags onto a free Farmboard slot.
2. Right-click the occupied slot and enter a target amount.
3. Farm the item. Farmboard updates the current amount automatically.

CONTROLS
--------
- Drag item onto slot: Add / replace tracked item
- Right-click occupied slot: Set target amount
- Shift + Right-click occupied slot: Remove item
- Left-click + drag board: Move board (when unlocked)
- Right-click board background: Open board menu
- Left-click minimap button: Show / hide all boards
- Right-click minimap button: Open global Farmboard menu
- Drag minimap button: Reposition it around the minimap

SLASH COMMANDS
--------------
/farmboard or /fb  - Show / hide all Farmboards
/fb new            - Create a new Farmboard
/fb show           - Show all Farmboards
/fb hide           - Hide all Farmboards
/fb reset          - Reset all Farmboard positions

INSTALLATION
------------
Extract the Farmboard folder to:
World of Warcraft/_retail_/Interface/AddOns/

After updating, use /reload or restart World of Warcraft.
